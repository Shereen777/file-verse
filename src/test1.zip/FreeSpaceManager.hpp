#ifndef Free_HPP
#define Free_HPP

#include "../include/odf_types.hpp"
#include <fstream>
#include <sstream>
#include <cstring>
#include <ctime>
#include <vector>
#include <algorithm>
#include <random>
#include <iostream>
#include "IndexGenerator.hpp"
#include "AVL.hpp"
#include "UserSystem.hpp"

using namespace std;

// ============================================================================
// FREE SPACE MANAGER
// ============================================================================

class FreeSpaceManager {
private:
    vector<bool> block_map;
    uint32_t total_blocks;
    uint32_t free_blocks_count;
    
public:
    FreeSpaceManager() : total_blocks(0), free_blocks_count(0) {}
    
    void initialize(uint32_t num_blocks) {
        total_blocks = num_blocks;
        free_blocks_count = num_blocks;
        block_map.assign(num_blocks, true);
    }
    
    int allocate_blocks(uint32_t count) {
        if (count > free_blocks_count) return -1;
        
        uint32_t found = 0;
        int start_block = -1;
        
        for (uint32_t i = 0; i < total_blocks; i++) {
            if (block_map[i]) {
                if (found == 0) start_block = i;
                found++;
                if (found == count) {
                    for (uint32_t j = start_block; j < start_block + count; j++) {
                        block_map[j] = false;
                    }
                    free_blocks_count -= count;
                    return start_block;
                }
            } else {
                found = 0;
                start_block = -1;
            }
        }
        return -1;
    }
    
    void free_blocks(uint32_t start, uint32_t count) {
        for (uint32_t i = start; i < start + count && i < total_blocks; i++) {
            if (!block_map[i]) {
                block_map[i] = true;
                free_blocks_count++;
            }
        }
    }
    
    uint32_t get_free_blocks() const { return free_blocks_count; }
    uint32_t get_total_blocks() const { return total_blocks; }
};

#endif