#ifndef User_HPP
#define User_HPP

#include "../include/odf_types.hpp"
#include <fstream>
#include <sstream>
#include <cstring>
#include <ctime>
#include <vector>
#include <algorithm>
#include <random>
#include <iostream>
#include "IndexGenerator.hpp"
#include "AVL.hpp"

using namespace std;

// ============================================================================
// USER SYSTEM (Pure AVL Tree-based)
// ============================================================================

struct UserSystem {
    vector<UserInfo> user_pool;
    AVLIndexTree index_tree;
    AVLNameTree username_tree;
    
    uint32_t add_user(const UserInfo& user) {
        uint32_t idx = user.user_index;
        
        if (index_tree.find(idx) != nullptr) {
            return 0;
        }
        
        user_pool.push_back(user);
        UserInfo* user_ptr = &user_pool.back();
        
        index_tree.insert(idx, user_ptr);
        username_tree.insert(user.username, idx);
        
        cout << "✓ User created: " << user.username 
             << " (Index: " << idx << ")\n";
        
        return idx;
    }
    
    UserInfo* find_user_by_index(uint32_t index) {
        return index_tree.find(index);
    }
    
    // UserInfo* find_user_by_username(const string& username) {
    //     uint32_t idx = username_tree.find(username);
    //     if (idx == 0) return nullptr;
    //     return index_tree.find(idx);
    // }
    
    int get_user_count() const {
        int count = 0;
        for (const auto& user : user_pool) {
            if (user.is_active) count++;
        }
        return count;
    }
};

#endif