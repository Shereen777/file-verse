#ifndef File_HPP
#define File_HPP

#include "../include/odf_types.hpp"
#include <fstream>
#include <sstream>
#include <cstring>
#include <ctime>
#include <vector>
#include <algorithm>
#include <random>
#include <iostream>
#include "IndexGenerator.hpp"
#include "UserSystem.hpp"
#include "FreeSpaceManager.hpp"

using namespace std;

// ============================================================================
// GENERALIZED AVL TREE FOR FILE SYSTEM NODES
// ============================================================================

// Forward declaration
struct FSNode;

struct AVLFSNode {
    string key;              // Node name (filename/dirname)
    FSNode* fs_node;         // Pointer to actual file system node
    int height;
    AVLFSNode* left;
    AVLFSNode* right;
    
    AVLFSNode(const string& k, FSNode* node) 
        : key(k), fs_node(node), height(1), left(nullptr), right(nullptr) {}
};

class AVLFSTree {
private:
    AVLFSNode* root;
     
    void inorder_recursive(AVLFSNode* node, std::function<void(FSNode*)> visit) {
        if (!node) return;
        inorder_recursive(node->left, visit);
        visit(node->fs_node);
        inorder_recursive(node->right, visit);
    }

    int height(AVLFSNode* node) {
        return node ? node->height : 0;
    }
    
    int balance_factor(AVLFSNode* node) {
        return node ? height(node->left) - height(node->right) : 0;
    }
    
    void update_height(AVLFSNode* node) {
        if (node) {
            node->height = 1 + max(height(node->left), height(node->right));
        }
    }
    
    AVLFSNode* rotate_right(AVLFSNode* y) {
        AVLFSNode* x = y->left;
        AVLFSNode* T2 = x->right;
        x->right = y;
        y->left = T2;
        update_height(y);
        update_height(x);
        return x;
    }
    
    AVLFSNode* rotate_left(AVLFSNode* x) {
        AVLFSNode* y = x->right;
        AVLFSNode* T2 = y->left;
        y->left = x;
        x->right = T2;
        update_height(x);
        update_height(y);
        return y;
    }
    
    AVLFSNode* insert_helper(AVLFSNode* node, const string& key, FSNode* fs_node) {
        if (!node) return new AVLFSNode(key, fs_node);
        
        if (key < node->key)
            node->left = insert_helper(node->left, key, fs_node);
        else if (key > node->key)
            node->right = insert_helper(node->right, key, fs_node);
        else
            return node; // Duplicate
        
        update_height(node);
        int balance = balance_factor(node);
        
        // Left Left
        if (balance > 1 && key < node->left->key)
            return rotate_right(node);
        
        // Right Right
        if (balance < -1 && key > node->right->key)
            return rotate_left(node);
        
        // Left Right
        if (balance > 1 && key > node->left->key) {
            node->left = rotate_left(node->left);
            return rotate_right(node);
        }
        
        // Right Left
        if (balance < -1 && key < node->right->key) {
            node->right = rotate_right(node->right);
            return rotate_left(node);
        }
        
        return node;
    }
    
    AVLFSNode* find_min(AVLFSNode* node) {
        while (node && node->left) {
            node = node->left;
        }
        return node;
    }
    
    AVLFSNode* remove_helper(AVLFSNode* node, const string& key, bool& deleted) {
        if (!node) {
            deleted = false;
            return nullptr;
        }
        
        if (key < node->key) {
            node->left = remove_helper(node->left, key, deleted);
        } else if (key > node->key) {
            node->right = remove_helper(node->right, key, deleted);
        } else {
            // Node found
            deleted = true;
            
            // Node with only one child or no child
            if (!node->left || !node->right) {
                AVLFSNode* temp = node->left ? node->left : node->right;
                
                if (!temp) {
                    // No child
                    temp = node;
                    node = nullptr;
                } else {
                    // One child
                    *node = *temp;
                }
                delete temp;
            } else {
                // Node with two children
                AVLFSNode* temp = find_min(node->right);
                node->key = temp->key;
                node->fs_node = temp->fs_node;
                node->right = remove_helper(node->right, temp->key, deleted);
            }
        }
        
        if (!node) return node;
        
        update_height(node);
        int balance = balance_factor(node);
        
        // Left Left
        if (balance > 1 && balance_factor(node->left) >= 0)
            return rotate_right(node);
        
        // Left Right
        if (balance > 1 && balance_factor(node->left) < 0) {
            node->left = rotate_left(node->left);
            return rotate_right(node);
        }
        
        // Right Right
        if (balance < -1 && balance_factor(node->right) <= 0)
            return rotate_left(node);
        
        // Right Left
        if (balance < -1 && balance_factor(node->right) > 0) {
            node->right = rotate_right(node->right);
            return rotate_left(node);
        }
        
        return node;
    }
    
    AVLFSNode* find_helper(AVLFSNode* node, const string& key) {
        if (!node) return nullptr;
        if (node->key == key) return node;
        if (key < node->key) return find_helper(node->left, key);
        return find_helper(node->right, key);
    }
    
    int count_nodes(AVLFSNode* node) {
        if (!node) return 0;
        return 1 + count_nodes(node->left) + count_nodes(node->right);
    }
    
    void delete_tree(AVLFSNode* node) {
        if (!node) return;
        delete_tree(node->left);
        delete_tree(node->right);
        delete node;
    }
    
public:
    AVLFSTree() : root(nullptr) {}
    
    ~AVLFSTree() {
        delete_tree(root);
    }
    void inorder_collect(AVLFSNode* node, std::vector<FSNode*>& result) {
        if (!node) return;
        inorder_collect(node->left, result);
        result.push_back(node->fs_node);
        inorder_collect(node->right, result);
    }

    AVLFSNode* getRoot(){
        return root;
    }
    
    void insert(const string& key, FSNode* fs_node) {
        root = insert_helper(root, key, fs_node);
    }
    
    FSNode* find(const string& key) {
        AVLFSNode* node = find_helper(root, key);
        return node ? node->fs_node : nullptr;
    }
    
    bool remove(const string& key) {
        bool deleted = false;
        root = remove_helper(root, key, deleted);
        return deleted;
    }
    
    vector<FSNode*> get_all_sorted() {
        vector<FSNode*> result;
        inorder_collect(root, result);
        return result;
    }
    
    int size() {
        return count_nodes(root);
    }
    
    bool empty() {
        return root == nullptr;
    }
};

// ============================================================================
// FILE SYSTEM NODE
// ============================================================================

struct FSNode {
    string name;
    string full_path;
    EntryType type;
    FSNode* parent;
    AVLFSTree children;  // Changed from vector to AVL tree
    
    string owner;
    uint32_t permissions;
    uint64_t size;
    uint64_t created_time;
    uint64_t modified_time;
    uint32_t inode;
    uint32_t start_block;
    uint32_t num_blocks;
    
    FSNode(const string& n, EntryType t, FSNode* p = nullptr) 
        : name(n), type(t), parent(p), permissions(0755), size(0),
          created_time(0), modified_time(0), inode(0), 
          start_block(0), num_blocks(0) {
        
        if (parent && parent->parent) {
            full_path = parent->full_path + "/" + name;
        } else if (parent) {
            full_path = "/" + name;
        } else {
            full_path = "/";
        }
    }
    
    // O(log n) insertion
    void add_child(FSNode* child) {
        children.insert(child->name, child);
    }
    
    // O(log n) search
    FSNode* find_child(const string& name) {
        return children.find(name);
    }
    
    // O(log n) removal
    bool remove_child(const string& name) {
        return children.remove(name);
    }
    
    // Get all children sorted by name - O(n)
    vector<FSNode*> get_children() {
        return children.get_all_sorted();
    }
    
    // Check if has children - O(1)
    bool has_children() {
        return !children.empty();
    }
    
    // Get children count - O(n) but can be optimized if needed
    int children_count() {
        return children.size();
    }
};

// ============================================================================
// FILE SYSTEM
// ============================================================================

class FileSystem {
private:
    FSNode* root;
    uint32_t next_inode;
    
    void delete_tree(FSNode* node) {
        if (!node) return;
        
        // Get all children and delete them
        vector<FSNode*> children = node->get_children();
        for (auto* child : children) {
            delete_tree(child);
        }
        delete node;
    }
    
    vector<string> split_path(const string& path) {
        vector<string> result;
        if (path.empty() || path == "/") return result;
        
        stringstream ss(path);
        string component;
        
        while (getline(ss, component, '/')) {
            if (!component.empty()) {
                result.push_back(component);
            }
        }
        return result;
    }
    
public:
    FileSystem() : next_inode(1) {
        root = new FSNode("/", EntryType::DIRECTORY, nullptr);
        root->inode = 0;
        root->created_time = time(nullptr);
        root->modified_time = root->created_time;
    }
    
    ~FileSystem() {
        delete_tree(root);
    }
    
    // O(d * log n) where d is depth and n is average children per directory
    FSNode* find_node(const string& path) {
        if (path == "/" || path.empty()) return root;
        
        vector<string> components = split_path(path);
        FSNode* current = root;
        
        for (const auto& comp : components) {
            current = current->find_child(comp);  // O(log n)
            if (!current) return nullptr;
        }
        return current;
    }
    
    // O(d * log n) for path traversal + O(log n) for insertion
    FSNode* create_node(const string& path, EntryType type, const string& owner) {
        size_t last_slash = path.find_last_of('/');
        string parent_path = (last_slash == 0) ? "/" : path.substr(0, last_slash);
        string name = path.substr(last_slash + 1);
        
        if (name.empty()) return nullptr;
        
        FSNode* parent = find_node(parent_path);
        if (!parent || parent->type != EntryType::DIRECTORY) return nullptr;
        
        // Check if already exists - O(log n)
        if (parent->find_child(name)) return nullptr;
        
        FSNode* node = new FSNode(name, type, parent);
        node->owner = owner;
        node->inode = next_inode++;
        node->created_time = time(nullptr);
        node->modified_time = node->created_time;
        node->permissions = (type == EntryType::DIRECTORY) ? 0755 : 0644;
        
        parent->add_child(node);  // O(log n)
        return node;
    }
    
    // O(d * log n) for path traversal + O(log n) for deletion
    bool delete_node(const string& path) {
        FSNode* node = find_node(path);
        if (!node || node == root) return false;
        
        // Check if directory is empty
        if (node->type == EntryType::DIRECTORY && node->has_children()) {
            return false;
        }
        
        node->parent->remove_child(node->name);  // O(log n)
        delete node;
        return true;
    }
    
    FSNode* get_root() { return root; }
};

#endif